# Guia didático rápido

## Resumo dos 4 cenários

### Funcionais
1. **01-ok-multibranch-python-api**
   - checkout do GitHub
   - validação estrutural
   - instalação Python
   - smoke test
   - build Docker

2. **02-ok-docker-compose-python-api**
   - checkout do GitHub
   - preparação do `.env`
   - validação do Compose
   - build dos serviços

### Com falha proposital
3. **03-broken-node-tests**
   - falha no `npm test`
   - causa: script de teste do projeto retorna `exit 1`

4. **04-broken-node-entrypoint**
   - falha no `node index.js`
   - causa: arquivo chamado não existe no repositório

## Sugestão de dinâmica em sala
- Rode primeiro um exemplo funcional.
- Mostre o console log e explique os stages.
- Em seguida rode um exemplo quebrado.
- Peça aos alunos para localizar se a falha está:
  - no código do projeto
  - na pipeline
  - na infraestrutura do agente
