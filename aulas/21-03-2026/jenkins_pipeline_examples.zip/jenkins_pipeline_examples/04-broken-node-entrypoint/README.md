# Exemplo 04 - Com erro proposital

## Objetivo
Demonstrar falha por configuração incorreta de entrypoint/arquivo inicial.

## Repositório utilizado
- https://github.com/rodrigobarbosa/rbcc-node-app

## Onde está o problema
A pipeline executa:

```bash
node index.js
```

Mas o repositório expõe `server.js` como arquivo existente. Logo, a execução falha por arquivo ausente.

## Uso em aula
Excelente para mostrar diferença entre:
- erro de infraestrutura Jenkins
- erro de comando na pipeline
- erro de convenção/estrutura do projeto
