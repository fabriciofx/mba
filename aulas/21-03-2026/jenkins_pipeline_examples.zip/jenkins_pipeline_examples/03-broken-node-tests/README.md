# Exemplo 03 - Com erro proposital

## Objetivo
Mostrar uma pipeline aparentemente correta, mas que falha na etapa de testes.

## Repositório utilizado
- https://github.com/rodrigobarbosa/rbcc-node-app

## Onde está o problema
O `package.json` define o script:

```json
"test": "echo \"Error: no test specified\" && exit 1"
```

Ou seja, a pipeline quebra ao executar `npm test`.

## Uso em aula
Peça aos alunos para identificar que o erro não está no Jenkins em si, mas no contrato de execução definido pelo próprio projeto Node.
