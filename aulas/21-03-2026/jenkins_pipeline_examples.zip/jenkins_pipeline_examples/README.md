# Exemplos de Pipelines Jenkins

Este pacote contém 4 exemplos de configuração de pipeline para Jenkins.

## Estrutura

- `01-ok-multibranch-python-api/` → exemplo funcional usando o repositório `product-api-devops-uniesp`
- `02-ok-docker-compose-python-api/` → exemplo funcional usando o repositório `product-api-devops-uniesp`
- `03-broken-node-tests/` → exemplo com erro proposital usando o repositório `rbcc-node-app`
- `04-broken-node-entrypoint/` → exemplo com erro proposital usando o repositório `rbcc-node-app`

## Pré-requisitos recomendados no Jenkins

- Git plugin
- Pipeline plugin
- Docker Pipeline plugin (para os exemplos com Docker)
- NodeJS plugin (opcional, caso queira toolchain gerenciada)
- Agente Jenkins com:
  - Git instalado
  - Docker e Docker Compose/`docker compose` instalados para os exemplos 1 e 2
  - Python 3.11+ disponível para o exemplo 1
  - Node.js 18+ disponível para os exemplos 3 e 4

## Observação didática

Os exemplos `03` e `04` foram construídos para **falhar de propósito**. O objetivo é demonstrar troubleshooting em pipeline.
