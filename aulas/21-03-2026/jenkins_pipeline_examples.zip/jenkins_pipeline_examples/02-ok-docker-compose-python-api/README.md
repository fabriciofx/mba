# Exemplo 02 - Funcional

## Objetivo
Pipeline declarativa focada em Docker Compose:
1. Faz checkout do repositório
2. Gera `.env` a partir de `.env.example`
3. Valida o arquivo Compose
4. Executa build dos serviços
5. Lista os serviços configurados

## Repositório utilizado
- https://github.com/rodrigobarbosa/product-api-devops-uniesp

## Cenário de aula
Bom exemplo para explicar integração entre Jenkins, Git e Docker Compose.
