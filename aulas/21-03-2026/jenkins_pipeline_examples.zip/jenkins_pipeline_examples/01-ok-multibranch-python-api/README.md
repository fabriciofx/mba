# Exemplo 01 - Funcional

## Objetivo
Pipeline declarativa que:
1. Faz checkout do repositório Python/FastAPI
2. Valida a estrutura mínima do projeto
3. Cria ambiente virtual
4. Instala dependências
5. Executa um smoke test de importação
6. Gera uma imagem Docker

## Repositório utilizado
- https://github.com/rodrigobarbosa/product-api-devops-uniesp

## Por que tende a funcionar
O repositório possui `requirements.txt`, `Dockerfile`, `docker-compose.yml`, pasta `app` e contrato OpenAPI, o que sustenta as etapas da pipeline.
